﻿Public Class Tree234
    Private root As New TreeNode                                                           ' Variable to serve as the root for the binary tree

    ' insert a DataItem
    Public Sub recAdd(strValue As String)
        Dim currentNode As TreeNode = root
        Dim diTempItem As New DataItem

        diTempItem.strData = strValue                       ' <-------   I can't get this variable to accept this value. (Fixed)

        If currentNode.isFull() Then ' If node full,
            split(currentNode)                    ' split 
            currentNode = currentNode.getParent()    ' back up                <------------ Keeps giving me the Parent node value over and over again
            ' search once
            currentNode = getNextChild(currentNode, strValue)
            ' end if(node Is full)

        ElseIf currentNode.isLeaf = True Then 'If node Is leaf,
            currentNode.insertItem(diTempItem) ' go insert New DataItem
        Else
            currentNode = getNextChild(currentNode, strValue)     ' node Is Not full, Not a leaf; so go to lower level
        End If
    End Sub

    Public Sub split(tnThisNode As TreeNode)     ' split the node
        ' assumes node Is full
        Dim diItemB, diItemC As DataItem
        Dim tnParent, tnChild1, tnChild2 As TreeNode
        Dim intItemIndex As Integer

        diItemC = tnThisNode.removeItem() ' remove items from
        diItemB = tnThisNode.removeItem() ' this node
        tnChild1 = tnThisNode.disconnectChild(1) ' remove children
        tnChild2 = tnThisNode.disconnectChild(2) ' From this node

        Dim newRight As New TreeNode       ' make New node

        If tnThisNode Is root Then ' If this Is the root,
            'Dim root As New TreeNode
            tnParent = root                 ' root Is our parent
            root.connectChild(0, tnThisNode)   ' connect To parent
        Else                              ' this node is not the root
            tnParent = tnThisNode.getParent() ' Get parent

            ' deal with parent
            intItemIndex = tnParent.insertItem(diItemB) ' item B To parent
            Dim n As Integer = tnParent.getNumItems()         ' total items in parent node?

            For j = n - 1 To intItemIndex + 1 Step -1   ' move parent's connections
                Dim tnTemp As TreeNode = tnParent.disconnectChild(j) ' one child
                tnParent.connectChild(j + 1, tnTemp) ' To the right

                ' connect newRight to parent
                tnParent.connectChild(intItemIndex + 1, newRight)

                ' deal with newRight
                newRight.insertItem(diItemC)       ' item C To newRight
                newRight.connectChild(1, tnChild1) ' connect To 0 And 1
                newRight.connectChild(2, tnChild2) ' On newRight
            Next
        End If
    End Sub

    ' gets appropriate child of node during search for value
    Public Function getNextChild(tnNode As TreeNode, strValue As String) As TreeNode
        ' Should be able to do this w/o a loop, since we should know index of correct child already
        Dim j As Integer

        ' assumes node Is Not empty, Not full, Not a leaf
        Dim intNumItems As Integer = tnNode.getNumItems()
        For j = 0 To j < intNumItems        ' For Each item In node
            ' are we less?
            If String.Compare(strValue, tnNode.getItem(j).strData) < 0 Then
                Return tnNode.getChild(j)  ' Return left child
                ' end for                   ' we're greater, so
            End If
        Next
        Return tnNode.getChild(j)        ' Return right child
    End Function

    Public Sub recPrint(tnThisNode As TreeNode)
        Dim strResult = tnThisNode.ToString

        Dim intNumItems As Integer = tnThisNode.getNumItems()            ' call ourselves for each child of this node
        For j = 0 To intNumItems

            Dim tnNextNode As TreeNode = tnThisNode.getChild(j)
            If tnNextNode IsNot Nothing Then
                recPrint(tnNextNode)
            Else
                Return
            End If
        Next
    End Sub
End Class
