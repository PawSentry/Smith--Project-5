﻿Public Class DataItem
    Public strData As String        ' the value to be stored at the current node

    Public WordCount As Integer = 1

    Public Sub DataItem(dd As String)  'constructor
        strData = dd
    End Sub
End Class
