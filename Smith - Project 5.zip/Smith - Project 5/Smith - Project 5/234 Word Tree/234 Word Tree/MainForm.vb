﻿Imports System
Imports System.IO

Public Class MainForm
    ' I created a modified 234 tree to record each word in a text document
    ' and the number of times each one occurs. After scanning the document 
    ' and parsing each word, I took away all punctuation and made all words lower case.
    ' Then, I added each word to the tree one by one.  If the word was already in the tree, 
    ' I incremented the counter; if not, I added the new word to the 234 Tree 
    ' and reset the counter to one. Finally, once the 234 tree was completed, 
    ' I used in-order traversal to print the words in alphabetical order along with the word count.

    Dim words As Array                                                                 ' Array to hold the parsed words from the text document
    Dim i As Integer = 0                                                               ' Pointer index for current word in the array
    Dim trTree As New Tree234

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Try-Catch statement to handle the text reader
        Try
            Dim readFile As StreamReader = New StreamReader("Text-Document.txt")       ' Variable to write down the file content
            Dim file As String                                                         ' Variable to hold the file content

            file = readFile.ReadToEnd()                                                ' Retrieves the entire file
            file = file.ToLower                                                        ' String is converted to all lowercase letter
            file = Replace(file, "-", " ")                                             ' String is stripped of all hyphens
            file = Replace(file, ",", "")                                              ' String is stripped of all commas
            file = Replace(file, ".", "")                                              ' String is stripped of all periods
            file = Replace(file, "'", "")                                              ' String is stripped of all single quotation marks
            file = Replace(file, """", "")                                             ' String is stripped of all double quotation marks
            file = Replace(file, "?", "")                                              ' String is stripped of all question marks
            file = Replace(file, vbCrLf, " ")                                          ' String is stripped of all new lines

            words = file.Split(" ")                                                    ' The file contents are converted into an array.

            readFile.Close()                                                           ' The file closes.

            ' This While loop will add the document's words to the binary tree.
            While i < words.Length
                If words(i) <> "" Then
                    trTree.recAdd(words(i))
                End If
                i += 1                              ' Increment to the next word in the array
            End While

        Catch ex As Exception
            ' This message displays if the file does not exist.
            MessageBox.Show("The file could not be found. Please check the file's name and try again.")
        End Try
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'Close the application.
        Me.Close()
    End Sub

    Private Sub btnDisplayCount_Click(sender As Object, e As EventArgs) Handles btnDisplayCount.Click
        ' Clear the list of the previous contents
        lstTree.Items.Clear()

        While i < words.Length
            If words(i) <> "" Then
                trTree.recPrint(words(i))
            End If
            i += 1
        End While

        ' Remove the topmost element in the list (the number of new lines)
        'lstTree.Items.RemoveAt(0)
    End Sub
End Class