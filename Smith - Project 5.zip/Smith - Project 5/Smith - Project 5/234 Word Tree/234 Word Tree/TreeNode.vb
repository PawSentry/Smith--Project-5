﻿Public Class TreeNode
    Private intOrder As Integer = 3
    Private intNumItems As Integer = 0
    Private tnParent As TreeNode
    Private arrChildArray(intOrder) As TreeNode
    Private arrItemArray(intOrder - 1) As DataItem

    'connect child to this node
    Public Sub connectChild(intChildNum As Integer, tnChild As TreeNode)
        arrChildArray(intChildNum) = tnChild
        If tnChild IsNot Nothing Then
            tnChild.tnParent = Me
        End If
    End Sub

    ' disconnect child from this node, return it
    Public Function disconnectChild(intChildNum As Integer) As TreeNode
        Dim tnTempNode As TreeNode = arrChildArray(intChildNum)
        arrChildArray(intChildNum) = Nothing
        Return tnTempNode
    End Function

    Public Function getChild(intChildNum As Integer) As TreeNode
        Return arrChildArray(intChildNum)
    End Function

    Public Function getParent() As TreeNode
        Return tnParent
    End Function

    Public Function isLeaf() As Boolean
        If arrChildArray(0) Is Nothing Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function getNumItems() As Integer
        Return intNumItems
    End Function

    Public Function getItem(index As Integer) As DataItem ' Get DataItem at index
        Return arrItemArray(index)
    End Function

    Public Function isFull() As Boolean
        If intNumItems = intOrder Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function insertItem(newItem As DataItem) As String
        ' assumes node Is Not full
        intNumItems += 1                          ' will add New item
        Dim newKey As String = newItem.strData       ' key of New item

        ' Should start this for loop at numItems-1

        For j = intNumItems - 1 To 0 Step -1        ' start on right, examine items
            If arrItemArray(j) Is Nothing Then          ' If item null,
                Continue For                      ' go left one cell
            Else                              ' Not null,
                ' get its key
                Dim strCurrKey As String = arrItemArray(j).strData

                If String.Compare(newKey, strCurrKey) < 0 Then ' If it's bigger
                    arrItemArray(j + 1) = arrItemArray(j) ' shift it right
                    ' ElseIf String.Compare(newKey, strCurrKey) = 0 Then   ' If it's equal
                    ' arrItemArray(j).WordCount += 1
                Else
                    arrItemArray(j + 1) = newItem   'insert New item
                    Return j + 1  ' Return index to new item
                End If
            End If
        Next                    ' shifted all items,
        arrItemArray(0) = newItem ' insert New item
        Return 0
    End Function

    Public Function removeItem()        ' remove largest item
        ' assumes node Not empty
        Dim temp As DataItem = arrItemArray(intNumItems - 1)  ' save item
        arrItemArray(intNumItems - 1) = Nothing          ' disconnect it
        intNumItems -= 1                             ' one less item
        Return temp                            ' Return item
    End Function
End Class